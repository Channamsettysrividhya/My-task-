class User:
    def __init__(self, user_id, pin):
        self.user_id = user_id
        self.pin = pin
        self.balance = 0

class Transaction:
    def __init__(self, amount, type):
        self.amount = amount
        self.type = type  # 'deposit' or 'withdraw'

class History:
    def __init__(self):
        self.transactions = []

    def add_transaction(self, transaction):
        self.transactions.append(transaction)

    def view_history(self):
        for transaction in self.transactions:
            print(f"Type: {transaction.type}, Amount: {transaction.amount}")

class Menu:
    @staticmethod
    def display():
        print("1. View Transactions")
        print("2. Withdraw Money")
        print("3. Deposit Money")
        print("4. Transfer Funds")
        print("5. Quit")

class ATM:
    def __init__(self):
        self.users = {}
        self.history = History()

    def register_user(self, user_id, pin):
        if user_id in self.users:
            print("User already exists.")
            return False
        self.users[user_id] = User(user_id, pin)
        return True

    def login(self, user_id, pin):
        if user_id in self.users and self.users[user_id].pin == pin:
            print("Login successful.")
            return True
        else:
            print("Invalid credentials.")
            return False

    def process(self):
        while True:
            print("\nWelcome to the ATM!")
            choice = input("Enter your user ID: ")
            pin = input("Enter your PIN: ")

            if self.login(choice, pin):
                while True:
                    Menu.display()
                    option = int(input("Select an option: "))
                    if option == 1:
                        self.history.view_history()
                    elif option == 2:
                        amount = float(input("Enter amount to withdraw: "))
                        self.users[choice].balance -= amount
                        self.history.add_transaction(Transaction(amount, "withdraw"))
                        print(f"Withdrawal of {amount} completed.")
                    elif option == 3:
                        amount = float(input("Enter amount to deposit: "))
                        self.users[choice].balance += amount
                        self.history.add_transaction(Transaction(amount, "deposit"))
                        print(f"Deposit of {amount} completed.")
                    elif option == 4:
                        recipient_id = input("Enter recipient user ID: ")
                        amount = float(input("Enter transfer amount: "))
                        if recipient_id in self.users and self.users[recipient_id].balance >= amount:
                            self.users[choice].balance -= amount
                            self.users[recipient_id].balance += amount
                            self.history.add_transaction(Transaction(amount, "transfer"))
                            print(f"Transfer of {amount} to {recipient_id} completed.")
                        else:
                            print("Insufficient balance or invalid recipient ID.")
                    elif option == 5:
                        break
                    else:
                        print("Invalid option selected.")

if __name__ == "__main__":
    atm = ATM()
    # Example usage
    # Register a new user
    atm.register_user("12345", "password")
    # Login and proceed with operations
    atm.process()
